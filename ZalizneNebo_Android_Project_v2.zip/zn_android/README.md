# Залізне Небо — Android

Android WebView wrapper around the supplied original map UI. The HTML, CSS and JS are packaged locally in the APK. NEPTUN API endpoints are proxied by the Android app; map tiles, MapLibre assets, Photon search and Telegram channel links require internet access.

## Build
GitHub Actions builds a debug APK on every push to `main` or via **Actions → Build Android APK → Run workflow**. Download the `ZalizneNebo-Android-APK` artifact from the completed run and extract `app-debug.apk`.

Package: `ua.zaliznebo`; minimum Android 6.0 (API 23).
