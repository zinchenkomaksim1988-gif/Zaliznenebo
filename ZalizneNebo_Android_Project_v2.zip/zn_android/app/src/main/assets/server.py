from __future__ import annotations

import json
import html
import re
import time
import os
import threading
import urllib.request
import webbrowser
from http.server import SimpleHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path

HOST = "127.0.0.1"
PORT = 8765
ROOT = Path(__file__).resolve().parent
NEPTUN_ALERTS_URL = "https://neptun.in.ua/api/v1/alerts"
NEPTUN_THREATS_URL = "https://neptun.in.ua/api/v1/threats"
NEPTUN_OBLASTS_GEOJSON_URL = "https://neptun.in.ua/oblasts.geojson"
NEPTUN_RAIONS_GEOJSON_URL = "https://neptun.in.ua/raions.geojson"
TELEGRAM_PUBLIC_URL = "https://t.me/s/zalizne_nebo"
TELEGRAM_CACHE = {"timestamp": 0.0, "items": []}


class Handler(SimpleHTTPRequestHandler):
    def translate_path(self, path: str) -> str:
        clean = path.split("?", 1)[0].split("#", 1)[0]
        relative = clean.lstrip("/") or "index.html"
        return str(ROOT / relative)

    def end_headers(self) -> None:
        self.send_header("Cache-Control", "no-store, no-cache, must-revalidate, max-age=0")
        self.send_header("Pragma", "no-cache")
        self.send_header("Expires", "0")
        super().end_headers()

    def do_GET(self) -> None:
        route = self.path.split("?", 1)[0]
        if route == "/api/alerts":
            self.proxy_json(NEPTUN_ALERTS_URL)
            return
        if route == "/api/threats":
            self.proxy_json(NEPTUN_THREATS_URL)
            return
        if route == "/api/oblasts-geojson":
            self.proxy_json(NEPTUN_OBLASTS_GEOJSON_URL)
            return
        if route == "/api/raions-geojson":
            self.proxy_json(NEPTUN_RAIONS_GEOJSON_URL)
            return
        if route == "/api/telegram-news":
            self.telegram_news()
            return
        super().do_GET()

    def telegram_news(self) -> None:
        try:
            now = time.time()
            if TELEGRAM_CACHE["items"] and now - TELEGRAM_CACHE["timestamp"] < 8:
                items = TELEGRAM_CACHE["items"]
            else:
                request = urllib.request.Request(
                    TELEGRAM_PUBLIC_URL,
                    headers={
                        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/124 Safari/537.36",
                        "Accept-Language": "uk-UA,uk;q=0.9,en;q=0.7",
                    },
                )
                with urllib.request.urlopen(request, timeout=15) as response:
                    page = response.read().decode("utf-8", errors="replace")

                blocks = re.findall(
                    r'<div class="tgme_widget_message_wrap[^>]*>(.*?)<div class="tgme_widget_message_footer',
                    page,
                    flags=re.S,
                )
                parsed = []
                for block in blocks:
                    post_match = re.search(r'data-post="([^"]+)"', block)
                    text_match = re.search(r'<div class="tgme_widget_message_text[^>]*>(.*?)</div>', block, flags=re.S)
                    time_match = re.search(r'<time[^>]+datetime="([^"]+)"', block)
                    if not post_match or not text_match:
                        continue
                    raw_text = re.sub(r'<br\s*/?>', '\n', text_match.group(1), flags=re.I)
                    raw_text = re.sub(r'<[^>]+>', '', raw_text)
                    clean_text = html.unescape(raw_text).strip()
                    clean_text = re.sub(r'\n{3,}', '\n\n', clean_text)
                    if not clean_text:
                        continue
                    parsed.append({
                        "text": clean_text,
                        "datetime": time_match.group(1) if time_match else "",
                        "url": "https://t.me/" + post_match.group(1),
                    })
                items = parsed[-10:]
                TELEGRAM_CACHE["timestamp"] = now
                TELEGRAM_CACHE["items"] = items

            body = json.dumps({"channel": "zalizne_nebo", "items": items}, ensure_ascii=False).encode("utf-8")
            self.send_response(200)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Cache-Control", "no-store")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
        except Exception as exc:
            body = json.dumps({"error": str(exc), "items": TELEGRAM_CACHE["items"]}, ensure_ascii=False).encode("utf-8")
            self.send_response(200 if TELEGRAM_CACHE["items"] else 502)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Cache-Control", "no-store")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

    def proxy_json(self, url: str) -> None:
        try:
            request = urllib.request.Request(
                url,
                headers={
                    "User-Agent": "Ukraine-Tactical-Radar/1.0",
                    "Accept": "application/json",
                },
            )
            with urllib.request.urlopen(request, timeout=12) as response:
                body = response.read()
            json.loads(body.decode("utf-8"))
            self.send_response(200)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Cache-Control", "no-store")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)
        except Exception as exc:
            body = json.dumps({"error": str(exc)}, ensure_ascii=False).encode("utf-8")
            self.send_response(502)
            self.send_header("Content-Type", "application/json; charset=utf-8")
            self.send_header("Cache-Control", "no-store")
            self.send_header("Content-Length", str(len(body)))
            self.end_headers()
            self.wfile.write(body)

    def log_message(self, fmt: str, *args: object) -> None:
        print(fmt % args)


def main() -> None:
    os.chdir(ROOT)
    server = ThreadingHTTPServer((HOST, PORT), Handler)
    url = f"http://{HOST}:{PORT}/"
    print(f"Карта запущена: {url}")
    threading.Timer(1.0, lambda: webbrowser.open(url)).start()
    try:
        server.serve_forever()
    except KeyboardInterrupt:
        pass
    finally:
        server.server_close()


if __name__ == "__main__":
    main()
