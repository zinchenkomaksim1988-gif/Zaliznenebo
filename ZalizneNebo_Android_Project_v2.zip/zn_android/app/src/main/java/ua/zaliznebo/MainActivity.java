package ua.zaliznebo;

import android.app.Activity;
import android.os.Bundle;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import androidx.webkit.WebViewAssetLoader;
import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

public class MainActivity extends Activity {
    private WebView webView;
    private WebViewAssetLoader assetLoader;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        getWindow().setStatusBarColor(android.graphics.Color.rgb(7,21,15));
        getWindow().setNavigationBarColor(android.graphics.Color.rgb(7,21,15));
        webView = new WebView(this);
        setContentView(webView);
        webView.getSettings().setJavaScriptEnabled(true);
        webView.getSettings().setDomStorageEnabled(true);
        webView.getSettings().setDatabaseEnabled(true);
        webView.getSettings().setLoadsImagesAutomatically(true);
        webView.getSettings().setMixedContentMode(android.webkit.WebSettings.MIXED_CONTENT_NEVER_ALLOW);
        assetLoader = new WebViewAssetLoader.Builder().addPathHandler("/assets/", new WebViewAssetLoader.AssetsPathHandler(this)).build();
        webView.setWebViewClient(new WebViewClient() {
            @Override public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                String path = request.getUrl().getPath();
                if (path != null && path.startsWith("/api/")) return proxyApi(path);
                return assetLoader.shouldInterceptRequest(request.getUrl());
            }
        });
        webView.loadUrl("https://appassets.androidplatform.net/assets/index.html");
    }

    private WebResourceResponse proxyApi(String path) {
        String target;
        if (path.equals("/api/alerts")) target = "https://neptun.in.ua/api/v1/alerts";
        else if (path.equals("/api/threats")) target = "https://neptun.in.ua/api/v1/threats";
        else if (path.equals("/api/oblasts-geojson")) target = "https://neptun.in.ua/oblasts.geojson";
        else if (path.equals("/api/raions-geojson")) target = "https://neptun.in.ua/raions.geojson";
        else if (path.equals("/api/telegram-news")) return telegramNews();
        else return json("{\"error\":\"not found\"}");
        HttpURLConnection connection = null;
        try {
            connection = (HttpURLConnection) new URL(target).openConnection();
            connection.setConnectTimeout(12000); connection.setReadTimeout(12000);
            connection.setRequestProperty("User-Agent", "Ukraine-Tactical-Radar-Android/1.0");
            connection.setRequestProperty("Accept", "application/json");
            int status = connection.getResponseCode();
            InputStream in = status >= 400 ? connection.getErrorStream() : connection.getInputStream();
            ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] buffer = new byte[8192]; int n;
            while ((n = in.read(buffer)) > 0) out.write(buffer, 0, n);
            in.close();
            return new WebResourceResponse("application/json", "UTF-8", status, status == 200 ? "OK" : "Upstream error", headers(), new ByteArrayInputStream(out.toByteArray()));
        } catch (Exception e) {
            String body = ("{\"error\":\"" + e.getClass().getSimpleName() + "\"}").replace("\\", "");
            return json(body);
        } finally { if (connection != null) connection.disconnect(); }
    }

    private WebResourceResponse telegramNews() {
        HttpURLConnection c = null;
        try {
            c = (HttpURLConnection) new URL("https://t.me/s/zalizne_nebo").openConnection();
            c.setConnectTimeout(12000); c.setReadTimeout(12000);
            c.setRequestProperty("User-Agent", "Mozilla/5.0 (Linux; Android 15) AppleWebKit/537.36 Chrome/124 Mobile Safari/537.36");
            InputStream in = c.getInputStream(); ByteArrayOutputStream out = new ByteArrayOutputStream();
            byte[] b = new byte[8192]; int n; while ((n = in.read(b)) > 0) out.write(b, 0, n); in.close();
            String page = new String(out.toByteArray(), StandardCharsets.UTF_8);
            java.util.regex.Matcher m = java.util.regex.Pattern.compile("(?s)<div class=\"tgme_widget_message_wrap[^>]*>(.*?)<div class=\"tgme_widget_message_footer").matcher(page);
            StringBuilder items = new StringBuilder(); int count = 0;
            while (m.find()) {
                String block = m.group(1);
                java.util.regex.Matcher post = java.util.regex.Pattern.compile("data-post=\"([^\"]+)\"").matcher(block);
                java.util.regex.Matcher tx = java.util.regex.Pattern.compile("(?s)<div class=\"tgme_widget_message_text[^>]*>(.*?)</div>").matcher(block);
                java.util.regex.Matcher tm = java.util.regex.Pattern.compile("<time[^>]+datetime=\"([^\"]+)\"").matcher(block);
                if (!post.find() || !tx.find()) continue;
                String text = tx.group(1).replaceAll("(?i)<br\\s*/?>", "\n").replaceAll("<[^>]+>", "");
                text = text.replace("&amp;", "&").replace("&quot;", "\"").replace("&#39;", "'").replace("&lt;", "<").replace("&gt;", ">").trim();
                if (text.isEmpty()) continue;
                if (count++ > 0) items.append(',');
                String date = tm.find() ? tm.group(1) : "";
                items.append("{\"text\":\"").append(escapeJson(text)).append("\",\"datetime\":\"").append(escapeJson(date)).append("\",\"url\":\"https://t.me/").append(escapeJson(post.group(1))).append("\"}");
                if (count >= 10) break;
            }
            return json("{\"channel\":\"zalizne_nebo\",\"items\":[" + items + "]}");
        } catch (Exception e) { return json("{\"channel\":\"zalizne_nebo\",\"items\":[]}"); }
        finally { if (c != null) c.disconnect(); }
    }
    private String escapeJson(String value) { return value.replace("\\", "\\\\").replace("\"", "\\\"").replace("\r", "").replace("\n", "\\n"); }

    private java.util.Map<String,String> headers() {
        java.util.Map<String,String> h = new java.util.HashMap<>();
        h.put("Cache-Control", "no-store"); h.put("Access-Control-Allow-Origin", "*"); return h;
    }
    private WebResourceResponse json(String body) {
        return new WebResourceResponse("application/json", "UTF-8", 200, "OK", headers(), new ByteArrayInputStream(body.getBytes(StandardCharsets.UTF_8)));
    }
    @Override public void onBackPressed() {
        if (webView != null && webView.canGoBack()) webView.goBack(); else super.onBackPressed();
    }
    @Override protected void onDestroy() { if (webView != null) webView.destroy(); super.onDestroy(); }
}
